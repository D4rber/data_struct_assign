/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;
import java.util.ArrayList;
import java.util.List;

public class TutorialGroup {
    private int number;
    private int maxStudents;

    public TutorialGroup(int number, int maxStudents) {
        this.number = number;
        this.maxStudents = maxStudents;
    }

    public int getNumber() {
        return number;
    }

    public int getMaxStudents() {
        return maxStudents;
    }
}



