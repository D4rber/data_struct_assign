/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

/**
 *
 * @author howei
 */
public class MessageUI {
    public static void displayInvalidChoiceMessage() {
    System.out.println("\nInvalid choice");
  }

  public static void displayExitMessage() {
    System.out.println("\nExiting system");
  }
  
  public static void nothingFound(){
      System.out.println("\nNothing found !!!");
  }
   public static void isFull(){
      System.out.println("\nIt is Full !!!");
  }
}
