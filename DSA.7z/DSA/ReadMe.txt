How To Run Application
1. open the project with netbean IDE
2. navigate to DSA folder -> DSA.java
3. run the main function 