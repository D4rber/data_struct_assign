/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author yongj
 */
public class Programme {
    private String pCode;
    private String pName;
    
    public Programme() {
        pCode = null;
        pName = null;
    }
    
    public Programme(String Code) {
        pCode = Code;
        this.pName = null;
    }
     public Programme(String pCode, String pName) {
        this.pCode = pCode;
        this.pName = pName;
    }
     
    public String getpCode() {
        return pCode;
    }

    public void setpCode(String pCode) {
        this.pCode = pCode;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        final Programme other = (Programme) obj;

        if (this.pCode != other.pCode) {
            return false;
        }

        return true;
    }
    
    @Override
    public String toString(){
        return String.format("\n\t Programme Code : %-15s Programme Name : %-30s", pCode, pName);
    }
}
